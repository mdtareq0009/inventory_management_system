<style scoped>
 label{
    font-size: 13px !important;
 }
.no-padding-right{
	padding: 0px !important;
}
.widget-box{
	margin:0px !important;
	border: 0px solid #fff !important;
}
.widget-header{
	border: 1px solid #ccc !important; 
	min-height: 26px !important; 
	background: #146C94 !important; 
	color:aliceblue !important; 
	font-weight: bolder !important;
    
}
.widget-body{
    padding-left:10px !important;
}
.widget-title{
	line-height: 25px !important;
}

td{
    border: 1px solid #9DB2BF;
}

.table-responsive .hover-tr{
    background-color: #E3F4F4 !important;
}

</style>
<template>
    <div>
        <form @submit.prevent="save">
            <div class="row">
                <div class="col-xs-12 col-md-10 col-lg-10 col-md-offset-1">
                    <div class="widget-box">
                        <div class="widget-header">
                            <h5 class="widget-title">Commission Payment Information</h5>
                        </div>
                        <div class="widget-body" style="background-color: #AEE2FF;">
                            <div class="widget-main">
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="form-group row">
                                            <label class="col-xs-4 control-label no-padding-right"> Referance Type </label>
                                            <div class="col-xs-1">
                                                <input type="radio" value="Doctor" placeholder="Transaction No." class="form-control" v-model="commissionpayment.reference_type" readonly/>
                                            </div>
                                            <div class="col-xs-3">
                                               <p style="margin:6px 5px 15px">Doctor</p> 
                                            </div>
                                            <div class="col-xs-1">
                                                <input type="radio" value="Agent" placeholder="Transaction No." class="form-control" v-model="commissionpayment.reference_type" readonly/>    
                                            </div>
                                            <div class="col-xs-3">
                                                <p style="margin:6px 5px 15px">Agent</p>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-xs-4 control-label no-padding-right"> Transaction No. </label>
                                            <div class="col-xs-8">
                                                <input type="text" placeholder="Transaction No." class="form-control" v-model="commissionpayment.transaction_number" readonly/>
                                            </div>
                                        </div>
                                       
                                        <div class="form-group row">
                                            <label class="col-xs-4 control-label no-padding-right"> Payment Type </label>
                                            <div class="col-xs-8">
                                                        <select class="form-control" v-model="commissionpayment.payment_type" required>
                                                            <option value="Cash">Cash</option>
                                                            <option value="Bank">Bank</option>
                                                        </select>
                                            </div>
                                            </div>
                                            <div class="form-group row" style="display:none;" v-bind:style="{display: commissionpayment.payment_type == 'Bank' ? '' : 'none'}">
                                                    <label class="col-xs-4 control-label no-padding-right">Bank Account</label>
                                                    <div class="col-xs-7">
                                                        <v-select v-bind:options="bankaccounts" class="select"  v-model="selectedBankAccount" label="display_name" placeholder="Select account"></v-select>
                                                    </div>
                                                    <div class="col-xs-1" style="padding: 0; margin-left: -10px;">
                                                        <a href="/bank_account_entry" target="_blank" class="add-button"><i class="fa fa-plus"></i></a>
                                                    </div>
                                            </div>
                                        <div class="form-group row" v-if="commissionpayment.reference_type == 'Doctor'">
                                            <label class="col-xs-4 control-label no-padding-right"> Doctor </label>
                                            <div class="col-xs-7">
                                                <v-select :options="doctors" class="select" v-model="selectedDoctor" label="display_name"></v-select>
                                            </div>
                                            <div class="col-xs-1" style="padding: 0; margin-left: -10px;">
                                                        <a href="/doctor_entry" target="_blank" class="add-button"><i class="fa fa-plus"></i></a>
                                            </div>
                                        </div>
                                        <div class="form-group row" v-if="commissionpayment.reference_type == 'Agent'">
                                            <label class="col-xs-4 control-label no-padding-right"> Agent </label>
                                            <div class="col-xs-7">
                                                <v-select :options="agents" class="select" v-model="selectedAgent" label="display_name"></v-select>
                                            </div>
                                            <div class="col-xs-1" style="padding: 0; margin-left: -10px;">
                                                        <a href="/agent_entry" target="_blank" class="add-button"><i class="fa fa-plus"></i></a>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-xs-4 control-label no-padding-right"> Transaction Type </label>
                                            <div class="col-xs-8">
                                                <select class="form-control"  v-model="commissionpayment.transaction_type">
                                                    <option value="Bill">Bill</option>
                                                    <option value="Payment" selected>Payment</option>
                                                </select>
                                            </div>
                                        </div>
                                       
                                    </div>
                                    <div class="col-sm-6">
                                       
                                        <div class="form-group row">
                                            <label class="col-xs-3 control-label no-padding-right"> Date </label>
                                            <div class="col-xs-9">
                                                <input type="date" placeholder="Transaction Date" class="form-control" v-model="commissionpayment.payment_date" @change="getCommissionPaymentTransaction()" />
                                            </div>
                                        </div>
                                         <div class="form-group row">
                                            <label class="col-xs-3 control-label no-padding-right"> Note </label>
                                            <div class="col-xs-9">
                                                <textarea name="Remarks"  class="form-control" cols="5" rows="2" v-model="commissionpayment.remark" placeholder="Remarks"></textarea>
                                            </div>
                                        </div>
                                          <div class="form-group row">
                                            <label class="col-xs-3 control-label no-padding-right"> Amount </label>
                                            <div class="col-xs-9">
                                                <input type="number" step="any" placeholder="Amount"  class="form-control" v-model="commissionpayment.amount" />
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <div class="col-xs-4 col-xs-offset-8">
                                                <input
                                                    type="submit"
                                                    class="btn btn-primary btn-sm"
                                                    value="Save"
                                                    v-bind:disabled="progress ? true : false"
                                                    style="color: #fff !important; margin-top: 0px; width: 100%; padding: 5px; font-weight: bold;"
                                                />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
        <br />
        <div class="row">
            <div class="col-sm-12 form-inline">
                <div class="form-group">
                    <input type="text" class="form-control" v-model="filter" placeholder="Filter" />
                </div>
            </div>
            <div class="col-md-12">
                <div class="table-responsive">
                    <datatable class="table table-hover table-bordered" :columns="columns" :data="commissionpayments" :filter="filter" :per-page="per_page">
                        <template slot-scope="{ row,index }">
                            <tr class="hover-tr">
                                <td>{{ index+1 }}</td>
                                <td>{{ row.payment_date }}</td>
                                <td>{{ row.transaction_number }}</td>
                                <td>{{ row.referance_name }}</td>
                                <td>{{ row.payment_type }}</td>
                                <td v-if="row.payment_type == 'Cash'">
                                    N/A                                    
                                </td>
                                <td v-if="row.payment_type == 'Bank'">
                                     {{ row.display_text}} 
                                </td>
                                <td>{{ row.transaction_type }}</td>
                                <td>{{ row.amount }}</td>
                                <td>{{ row.remark }}</td>
                                <td>
                                    <span v-if="role != 'User'">
                                        <a class="blue" href="javascript:" @click="editCommissionPayment(row)">
                                            <i class="ace-icon fa fa-pencil bigger-130"></i>
                                        </a>
                                        <a class="red" href="javascript:" @click="deleteCommissionPayment(row.id)">
                                            <i class="ace-icon fa fa-trash bigger-130"></i>
                                        </a>
                                    </span>
                                </td>
                            </tr>
                        </template>
                    </datatable>
                    <datatable-pager class="datatable-pagination" v-model="page" type="abbreviated"></datatable-pager>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
import moment from 'moment';
export default {
    props: ['role'],
    data () {

        return {
            commissionpayment: {
                id                : '',
                transaction_number: '',
                account_id        : '',
                reference_id      : '',
                patient_id        : '',
                reference_type    : 'Doctor',
                payment_date      : moment().format('YYYY-MM-DD'),
                transaction_type  : 'Bill',
                payment_type      : 'Cash',
                amount            : 0,
                remark            : '',
            },

            commissionpayments: [],
            bankaccounts: [],
            selectedBankAccount: null,
            doctors: [],
            selectedDoctor: null,
            agents: [],
            selectedAgent: null,
            columns     : [
                { label: 'S/L No.', field: 'sl_no', align: 'center'},
                { label: 'Transaction date', field: 'payment_date', align: 'center' },
                { label: 'Transaction number', field: 'transaction_number', align: 'center' },
                { label: 'Referance', field: 'referance_name', align: 'center' },
                { label: 'Payment Type', field: 'payment_type', align: 'center' },
                { label: 'Account Name', field: 'display_text', align: 'center' },
                { label: 'Transaction Type', field: 'transaction_type', align: 'center' },
                { label: 'Amount', field: 'amount', align: 'center' },
                { label: 'Note', field: 'remark', align: 'center' },
                { label: 'Action', align: 'center', filterable: false }
            ],
            page: 1,
            per_page: 10,
            filter: '',
            progress: false
        }
    },
   
    created(){
        this.getBankAccount();
        this.getAgents();
        this.getDoctors();
        this.getCommissionPaymentCode();
        this.getCommissionPaymentTransaction();
    },
    methods: {
        
        getBankAccount(){
            axios.get('/get_bankaccounts').then(res=>{
                this.bankaccounts = res.data;
            })
        },
     
        getDoctors(){
            axios.get('/get_doctors').then(res=>{
                    this.doctors = res.data;
            })
        },
        getAgents(){
            axios.get('/get_agents').then(res=>{
                this.agents = res.data;
            })
        },

        getCommissionPaymentTransaction(){
            axios.post('/get_commission_payments',{date: this.commissionpayment.payment_date}).then(res=>{
                this.commissionpayments = res.data;
            })
        },
        getCommissionPaymentCode(){
            axios.get('/get_commission_payment_code').then(res=>{
                this.commissionpayment.transaction_number = res.data;
            })
        },

        save(){

            if(this.selectedDoctor == null &&  this.commissionpayment.reference_type == "Doctor" ){
                alert('Select Doctor');
                return;
            }
            if(this.selectedAgent == null &&  this.commissionpayment.reference_type == "Agent"){
                alert('Select Agent');
                return;
            }
           
          
            this.progress = true;

            if(this.commissionpayment.payment_type == 'Cash'){

                this.commissionpayment.account_id  = null;
            }else{
                this.commissionpayment.account_id  = this.selectedBankAccount.id;
            }

            if(this.commissionpayment.reference_type == "Doctor"){
                this.commissionpayment.reference_id = this.selectedDoctor.id;
            }

            if(this.commissionpayment.reference_type == "Agent"){
                this.commissionpayment.reference_id = this.selectedAgent.id;
            }
            
            let url = '/store-commissionpayment';
            if(this.commissionpayment.id != ''){
                url = '/update-commissionpayment';
            }
            let data = {
                commissionpayment: this.commissionpayment
			}
            
            axios.post(url, data).then(res=>{
                this.progress = false;
                this.$toaster.success(res.data.message);
                this.clear();
                this.getDoctors();
                this.getAgents();
                this.getBankAccount();
                this.getCommissionPaymentTransaction();
                this.getCommissionPaymentCode();
            }).catch(error=>{
                this.progress = false;
                let e = error.response.data;
                if(e.hasOwnProperty('message')){
                    this.$toaster.error(e.message);
                }else{
                    Object.entries(e).forEach(([key, val])=>{
                        this.$toaster.error(val[0]);
                    })
                }
            })
        },
        clear(){
            this.commissionpayment = {
                id                : '',
                transaction_number: '',
                account_id        : '',
                reference_id      : '',
                patient_id        : '',
                reference_type    : 'Doctor',
                payment_date      : moment().format('YYYY-MM-DD'),
                transaction_type  : 'Bill',
                payment_type      : 'Cash',
                amount            : 0,
                remark            : '',
            };
            this.selectedBankAccount = null;
            this.selectedDoctor      = null;
            this.selectedAgent       = null;
        },
        
     
        editCommissionPayment(row){
            this.commissionpayment = {
                id                : row.id,
                transaction_number: row.transaction_number,
                reference_id      : row.reference_id,
                reference_type      : row.reference_type,
                account_id        : row.account_id,
                payment_date      : row.payment_date,
                payment_type      : row.payment_type,
                transaction_type  : row.transaction_type,
                amount            : row.amount,
                remark            : row.remark,
            }

            this.selectedBankAccount = {
                id          : row.account_id,
                display_name: row.display_text,
            }
            if(row.reference_type=="Doctor"){

                this.selectedDoctor = {
                    id          : row.reference_id,
                    display_name: row.referance_name,
                }
            }
            if(row.reference_type=="Agent"){
                this.selectedAgent = {
                    id          : row.reference_id,
                    display_name: row.referance_name,
                }
            }

        },
        deleteCommissionPayment(id){
            Swal.fire({
                title: '<strong>Are you sure!</strong>',
                html: '<strong>Want to delete this?</strong>',
                customClass: 'swal-wide',
                showDenyButton: true,
                confirmButtonText: `Ok`,
                denyButtonText: `Cancel`,
            }).then((result) => {
                if (result.isConfirmed) {
                    axios.post('/delete-commissionpayment', {id}).then(res=>{
                        let r = res.data;
                        Swal.fire({
                            icon: 'success',
                            title: r.message,
                            showConfirmButton: false,
                            timer: 1500
                        })
                        this.clear();
                        this.getDoctors();
                        this.getAgents();
                        this.getBankAccount();
                        this.getCommissionPaymentTransaction();
                        this.getCommissionPaymentCode();
                    }).catch(error => {
                        let e = error.response.data;

                        if(e.hasOwnProperty('message')){
                            if(e.hasOwnProperty('errors')){
                                Object.entries(e.errors).forEach(([key, val])=>{
                                    this.$toaster.error(val[0]);
                                })
                            }else{
                                this.$toaster.error(e.message);
                            }
                        }else{
                            this.$toaster.error(e);
                        }
                    })
                }
            })
        }
    }
}
</script>