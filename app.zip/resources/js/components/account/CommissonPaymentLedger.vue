
<style scoped>
.v-select{
		margin-top:1.5px;
        float: right;
        min-width: 180px;
        margin-left: 5px;
	}
	.v-select .dropdown-toggle{
		padding: 0px;
        height: 25px;
	}
	.v-select input[type=search], .v-select input[type=search]:focus{
		margin: 0px;
	}
	.v-select .vs__selected-options{
		overflow: hidden;
		flex-wrap:nowrap;
	}
	.v-select .selected-tag{
		margin: 2px 0px;
		white-space: nowrap;
		position:absolute;
		left: 0px;
	}
	.v-select .vs__actions{
		margin-top:-5px;
	}
	.v-select .dropdown-menu{
		width: auto;
		overflow-y:auto;
	}
	#searchForm select{
		padding:0;
		border-radius: 4px;
	}
	#searchForm .form-group{
		margin-right: 5px;
	}
	#searchForm *{
		font-size: 13px;
	}

</style>
<template>
    <div>
	<div class="row" style="border-bottom: 1px solid #ccc;padding: 3px 0;">
		<div class="col-md-12">
			<form class="form-inline" id="searchForm" @submit.prevent="getSearchResult">
				<div class="form-group">
					<label>Search Type</label>
					<select class="form-control" v-model="searchType" @change="onChangeSearchType">
						<option value="">Select Type</option>
						<option value="doctor">By Doctor</option>
						<option value="agent">By Agent</option>
					</select>
				</div>
				<div class="form-group" style="display:none;" v-bind:style="{display: searchType == 'doctor' && doctors.length > 0 ? '' : 'none'}">
					<label style="margin-top:5px;">Doctor</label>
					<v-select v-bind:options="doctors" v-model="selectedDoctor" label="display_name"></v-select>
				</div>

				<div class="form-group" style="display:none;" v-bind:style="{display: searchType == 'agent' && agents.length > 0 ? '' : 'none'}">
					<label style="margin-top:5px;">Agent</label>
					<v-select v-bind:options="agents" v-model="selectedAgent" label="display_name"></v-select>
				</div>


				<div class="form-group">
					<input type="date" class="form-control" v-model="dateFrom">
				</div>

				<div class="form-group">
					<input type="date" class="form-control" v-model="dateTo">
				</div>

				<div class="form-group" style="margin-top: -5px;">
					<input type="submit" value="Search">
				</div>
			</form>
		</div>
	</div>

		<div class="row" style="display:none;" v-bind:style="{display: showTable ? '' : 'none'}">
			<div class="col-md-12" style="margin-top:15px;margin-bottom:15px;">
				<a href="" @click.prevent="print"><i class="fa fa-print"></i> Print</a>
			</div>
			<div class="col-md-12">
				<div class="table-responsive" id="printContent">
					<table class="table table-bordered table-condensed">
						<thead>
							<tr class="hover-tr">
								<th style="text-align:center">Date</th>
								<th style="text-align:center">Description</th>
								<th style="text-align:center">Payment Type</th>
								<th style="text-align:center">Bill</th>
								<th style="text-align:center">Payment</th>
								<th style="text-align:center">Balance</th>
							</tr>
						</thead>
					<tbody>
						<tr class="hover-tr">
							<td></td>
							<td style="text-align:left;">Previous Balance</td>
							<td colspan="3"></td>
							<td style="text-align:right;">{{ previousBalance }}</td>
						</tr>
						<tr v-for="(row,sl) in ledger" :key="sl" class="hover-tr">
							<td>{{ row.date }}</td>
							<td style="text-align:left;">{{ row.description }}</td>
							<td style="text-align:left;">{{ row.payment_type }}</td>
							<td style="text-align:right;">{{ row.in_amount }}</td>
							<td style="text-align:right;">{{ row.out_amount }}</td>
							<td style="text-align:right;">{{ row.balance }}</td>
						</tr>
					</tbody>
					<tbody v-if="ledger.length == 0">
						<tr>
							<td colspan="5">No records found</td>
						</tr>
					</tbody>
					</table>
				</div>
			</div>
		</div>

		<div class="row" style="display:none;padding-top: 15px;" v-bind:style="{display: ledger.length > 0 ? 'none' : ''}">
			<div class="col-md-12 text-center">
				No records found
			</div>
		</div>
	</div>
</template>

<script>
import moment from 'moment';
export default {
    props: ['role'],
    data(){
			return {
				searchType     : '',
				dateFrom       : moment().format('YYYY-MM-DD'),
				dateTo         : moment().format('YYYY-MM-DD'),
				doctors        : [],
				selectedDoctor : null,
				agents         : [],
				selectedAgent  : null,
				ledger         : [],
				previousBalance: 0.00,
				showTable      : false,
			}
		},
        created(){
            this.getBranchInfo();
        },
		methods: {
		
			onChangeSearchType(){
				this.showTable      = false,
				this.ledger         = [];
				this.previousBalance =  0.00;
				if(this.searchType == 'doctor'){
					this.getDoctors();
					this.agents         = [];
					this.selectedAgent  = null;
				} 
				else if(this.searchType == 'agent'){
					this.getAgents();
					this.doctors         = [];
					this.selectedDoctor  = null;
				}
				
			},
            getBranchInfo(){
                axios.get('/get_branch_info').then(res=>{
                    this.branch = res.data;
                })
            },
			getAgents(){
				axios.get('/get_agents').then(res => {
					this.agents = res.data;
				})
			},
			getDoctors(){
				axios.get('/get_doctors').then(res => {
					this.doctors = res.data;
				})
			},
		
			getSearchResult(){
				if(this.searchType != 'doctor'){
					this.selectedDoctor = null;
				}

				if(this.searchType != 'agent'){
					this.selectedAgent= null;
				}
				if(this.selectedDoctor == null && this.searchType== "doctor"){
					alert('Select Doctor');
					return;
				}
				if(this.selectedAgent == null && this.searchType== "agent"){
					alert('Select Agent');
					return;
				}

				if(this.searchType == 'doctor') {
					this.getDoctorLegderRecord();
				} 
				if(this.searchType == 'agent') {
					this.getAgentLegderRecord();
				} 
			},
			getDoctorLegderRecord(){
				let filter = {
					type: 'Doctor',
					doctorId: this.selectedDoctor == null ? '' : this.selectedDoctor.id,
					fromDate: this.dateFrom,
					toDate: this.dateTo
				}
				axios.post('/get_commission_doctor_ledger', filter).then(res => {
					this.ledger = res.data.ledger;
					this.previousBalance =  res.data.previousBalance;
                    console.log(res.data.previousBalance);
					this.showTable = true;
				}).catch(error => {
					if(error.response){
						alert(`${error.response.status}, ${error.response.statusText}`);
					}
				})
			},
			getAgentLegderRecord(){
				let filter = {
					agentId: this.selectedAgent == null ? '' : this.selectedAgent.id,
					type: 'Agent',
					fromDate: this.dateFrom,
					toDate: this.dateTo
				}
				axios.post('/get_commission_agent_ledger', filter).then(res => {
					this.ledger = res.data.ledger;
					this.previousBalance =  res.data.previousBalance;
                    console.log(res.data.previousBalance);
					this.showTable = true;
				}).catch(error => {
					if(error.response){
						alert(`${error.response.status}, ${error.response.statusText}`);
					}
				})
			},
	

			async print(){
				let dateText = '';
				if(this.dateFrom != '' && this.dateTo != ''){
					dateText = `Statement from <strong>${this.dateFrom}</strong> to <strong>${this.dateTo}</strong>`;
				}

				let agentText = '';
				if(this.selectedAgent != null && this.selectedAgent.id != '' && this.searchType == 'agent'){
					agentText = `<strong>Sold by: </strong> ${this.selectedAgent.display_name}`;
				}

				let doctorText = '';
				if(this.selectedDoctor != null && this.selectedDoctor.id != '' && this.searchType == 'doctor'){
					doctorText = `<strong>Doctor: </strong> ${this.selectedDoctor.display_name}<br>`;
				}



				let reportContent = `
					<div class="container">
						<div class="row">
							<div class="col-xs-12 text-center">
								<h3>Issue Record</h3>
							</div>
						</div>
						<div class="row">
							<div class="col-xs-6">
								${agentText} ${doctorText}
							</div>
							<div class="col-xs-6 text-right">
								${dateText}
							</div>
						</div>
						<div class="row">
							<div class="col-xs-12">
								${document.querySelector('#reportContent').innerHTML}
							</div>
						</div>
					</div>
				`;

				var reportWindow = window.open('', 'PRINT', `height=${screen.height}, width=${screen.width}`);
				reportWindow.document.write(`
                <link rel="stylesheet" href="/assets/css/bootstrap.min.css">
                <div class="container">
                    <div class="row">
                        <div class="col-xs-2"><img src="${this.branch.logo}" alt="Logo" style="height:80px;" /></div>
                        <div class="col-xs-10" style="padding-top:20px;">
                            <strong style="font-size:18px;">${this.branch.name}</strong><br>
                            <p style="white-space: pre-line;">${this.branch.address}</p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-xs-12">
                            <div style="border-bottom: 4px double #454545;margin-top:7px;margin-bottom:7px;"></div>
                        </div>
                    </div>
                </div>
            `);

				reportWindow.document.head.innerHTML += `
					<style>
						.record-table{
							width: 100%;
							border-collapse: collapse;
						}
						.record-table thead{
							background-color: #0097df;
							color:white;
						}
						.record-table th, .record-table td{
							padding: 3px;
							border: 1px solid #454545;
						}
						.record-table th{
							text-align: center;
						}
					</style>
				`;
				reportWindow.document.body.innerHTML += reportContent;

				if(this.searchType == '' || this.searchType == 'user'){
					let rows = reportWindow.document.querySelectorAll('.record-table tr');
					rows.forEach(row => {
						row.lastChild.remove();
					})
				}


				reportWindow.focus();
				await new Promise(resolve => setTimeout(resolve, 1000));
				reportWindow.print();
				reportWindow.close();
			}
		}

}
</script>