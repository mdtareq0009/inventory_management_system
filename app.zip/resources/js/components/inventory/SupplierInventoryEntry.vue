
<style scoped>
 label{
    font-size: 13px !important;
 }
.no-padding-right{
	padding: 0px !important;
}
.widget-box{
	margin:0px !important;
	border: 0px solid #fff !important;
}
.widget-header{
	border: 1px solid #ccc !important; 
	min-height: 26px !important; 
	background: #146C94 !important; 
	color:aliceblue !important; 
	font-weight: bolder !important;
    
}
.widget-body{
    padding-left:10px !important;
}
.widget-title{
	line-height: 25px !important;
}
td{
    border: 1px solid #9DB2BF;
}
.table-responsive .hover-tr{
    background-color: #E3F4F4 !important;
-webkit-transition: .5s all;   
    -webkit-transition-delay: .05s; 
    -moz-transition: .5s all;   
    -moz-transition-delay: .05s; 
    -ms-transition: .5s all;   
    -ms-transition-delay: .05s; 
    -o-transition: .5s all;   
    -o-transition-delay: .05s; 
    transition: .5s all;   
    transition-delay: .05s; 
}
.table-responsive .hover-tr:hover{
background-color: #62CDFF !important;
transition: 0s all;   
-webkit-transition-delay: 0s;
    -moz-transition-delay: 0s;
    -ms-transition-delay: 0s;
    -o-transition-delay: 0s;
    transition-delay: 0s;
}
</style>
<template>
    <div>
        <form @submit.prevent="save">
            <div class="row">
                <div class="col-xs-12 col-md-10 col-lg-10 col-md-offset-1">
                    <div class="widget-box">
                        <div class="widget-header">
                            <h5 class="widget-title">Inventory Supplier Information</h5>
                        </div>

                        <div class="widget-body" style="background-color: #AEE2FF;margin-bottom: 5px;">
                            <div class="widget-main">
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="form-group row">
                                            <label class="col-xs-4 control-label no-padding-right"> Supplier Code </label>
                                            <div class="col-xs-8">
                                                <input type="text" name="employee_code" class="form-control" v-model="supplierinventory.supplier_code" readonly />
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-xs-4 control-label no-padding-right"> Name </label>
                                            <div class="col-xs-8">
                                                <input type="text" placeholder="Name" class="form-control" v-model="supplierinventory.name" required />
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-xs-4 control-label no-padding-right"> Owner Name </label>
                                            <div class="col-xs-8">
                                                <input type="text" placeholder="Owner Name" class="form-control" v-model="supplierinventory.owner_name" required />
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-xs-4 control-label no-padding-right"> Mobile </label>
                                            <div class="col-xs-8">
                                                <input type="text" placeholder="Mobile" class="form-control" v-model="supplierinventory.mobile" required />
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="col-sm-6">
                                         <div class="form-group row">
                                            <label class="col-xs-4 control-label no-padding-right"> Address </label>
                                            <div class="col-xs-8">
                                                <input type="text" placeholder="Address" class="form-control" v-model="supplierinventory.address" required />
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-xs-4 control-label no-padding-right"> Remarks </label>
                                            <div class="col-xs-8">
                                                <textarea placeholder="Remarks" class="form-control" v-model="supplierinventory.remark" rows="2"></textarea>
                                            </div>
                                        </div>
                                        <br />
                                        <div class="form-group row">
                                            <div class="col-xs-4 col-xs-offset-8">
                                                <input
                                                    type="submit"
                                                    class="btn btn-primary btn-sm"
                                                    value="Save"
                                                    v-bind:disabled="progress ? true : false"
                                                    style="color: #fff !important; margin-top: 0px; width: 100%; padding: 5px; font-weight: bold;"
                                                />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                
            </div>
        </form>
        <br />
        <div class="row">
            <div class="col-sm-12 form-inline">
                <div class="form-group">
                    <input type="text" class="form-control" v-model="filter" placeholder="Filter" />
                </div>
            </div>
            <div class="col-md-12">
                <div class="table-responsive">
                    <datatable class="table table-hover table-bordered" :columns="columns" :data="supplierinventorys" :filter="filter" :per-page="per_page">
                        <template slot-scope="{ row }">
                            <tr class="hover-tr">
                                <td>{{ row.supplier_code }}</td>
                                <td>{{ row.name }}</td>
                                <td>{{ row.owner_name }}</td>
                                <td>{{ row.mobile }}</td>
                                <td>{{ row.address }}</td>
                                <td>{{ row.remark }}</td>
                                <td>
                                    <span v-if="role != 'User'">
                                        <a class="blue" href="javascript:" @click="editSupplierInventory(row)">
                                            <i class="ace-icon fa fa-pencil bigger-130"></i>
                                        </a>
                                        <a class="red" href="javascript:" @click="deleteSupplierInventory(row.id)">
                                            <i class="ace-icon fa fa-trash bigger-130"></i>
                                        </a>
                                    </span>
                                </td>
                            </tr>
                        </template>
                    </datatable>
                    <datatable-pager class="datatable-pagination" v-model="page" type="abbreviated"></datatable-pager>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
import moment from 'moment';
export default {
    props: ['role'],
    data () {
        return {
            supplierinventory: {
                id           : '',
                supplier_code: '',
                name         : '',
                owner_name   : '',
                mobile       : '',
                address      : '',
                remark       : '',
            },

            supplierinventorys: [],

            columns: [
                { label: 'Supplier Code', field: 'supplier_code', align: 'center'},
                { label: 'Name', field: 'name', align: 'center' },
                { label: 'Owner Name', field: 'owner_name', align: 'center' },
                { label: 'Mobile', field: 'unit_name', align: 'center' },
                { label: 'Address', field: 'address', align: 'center' },
                { label: 'Remark', field: 'remark', align: 'center' },
                { label: 'Action', align: 'center', filterable: false }
            ],
            page: 1,
            per_page: 10,
            filter: '',
            progress: false
        }
    },
   
    created(){;
        this.getSupplierInventoryCode();
        this.getSupplierInventory();
    },
    methods: {

        getSupplierInventory(){
            axios.get('/get_supplierinventorys').then(res=>{
                this.supplierinventorys = res.data;
            })
        },
        getSupplierInventoryCode(){
            axios.get('/get_supplier_inventory_code').then(res=>{
                this.supplierinventory.supplier_code = res.data;
            })
        },
       

        save(){
            this.progress = true;

            let url = '/store-supplierinventory';

            if(this.supplierinventory.id != ''){
                url = '/update-supplierinventory';
            }
            
            let fd = new FormData();
            fd.append('supplierinventorys', JSON.stringify(this.supplierinventory));
            axios.post(url, fd).then(res=>{
                this.progress = false;
                this.$toaster.success(res.data.message);
                this.clear();
                this.getSupplierInventoryCode();
                this.getSupplierInventory();    
            }).catch(error=>{
                this.progress = false;
                let e = error.response.data;
                if(e.hasOwnProperty('message')){
                    this.$toaster.error(e.message);
                }else{
                    Object.entries(e).forEach(([key, val])=>{
                        this.$toaster.error(val[0]);
                    })
                }
            })
        },
        clear(){
            this.supplierinventory = {
                id           : '',
                supplier_code: '',
                name         : '',
                owner_name   : '',
                mobile       : '',
                address      : '',
                remark       : '',
            };
        },
        
     
        editSupplierInventory(row){
             
            
          
            this.supplierinventory = {
                id           : row.id,
                supplier_code: row.supplier_code,
                name         : row.name,
                owner_name   : row.owner_name,
                mobile       : row.mobile,
                address      : row.address,
                remark       : row.remark
            }

        },
        deleteSupplierInventory(id){
            Swal.fire({
                title: '<strong>Are you sure!</strong>',
                html: '<strong>Want to delete this?</strong>',
                showDenyButton: true,
                confirmButtonText: `Ok`,
                denyButtonText: `Cancel`,
            }).then((result) => {
                if (result.isConfirmed) {
                    axios.post('/delete-supplierinventory', {id}).then(res=>{
                        let r = res.data;
                        Swal.fire({
                            icon: 'success',
                            title: r.message,
                            showConfirmButton: false,
                            timer: 1500
                        })
                        this.clear();
                        this.getSupplierInventoryCode();
                        this.getSupplierInventory();
                    }).catch(error => {
                        let e = error.response.data;

                        if(e.hasOwnProperty('message')){
                            if(e.hasOwnProperty('errors')){
                                Object.entries(e.errors).forEach(([key, val])=>{
                                    this.$toaster.error(val[0]);
                                })
                            }else{
                                this.$toaster.error(e.message);
                            }
                        }else{
                            this.$toaster.error(e);
                        }
                    })
                }
            })
        }
    }
}
</script>