
<style scoped>
.v-select{
		margin-top:1.5px;
        float: right;
        min-width: 180px;
        margin-left: 5px;
	}
	.v-select .dropdown-toggle{
		padding: 0px;
        height: 25px;
	}
	.v-select input[type=search], .v-select input[type=search]:focus{
		margin: 0px;
	}
	.v-select .vs__selected-options{
		overflow: hidden;
		flex-wrap:nowrap;
	}
	.v-select .selected-tag{
		margin: 2px 0px;
		white-space: nowrap;
		position:absolute;
		left: 0px;
	}
	.v-select .vs__actions{
		margin-top:-5px;
	}
	.v-select .dropdown-menu{
		width: auto;
		overflow-y:auto;
	}
	#searchForm select{
		padding:0;
		border-radius: 4px;
	}
	#searchForm .form-group{
		margin-right: 5px;
	}
	#searchForm *{
		font-size: 13px;
	}
</style>
<template>
    <div id="issueRecord">
	<div class="row" style="border-bottom: 1px solid #ccc;padding: 3px 0;">
		<div class="col-md-12">
			<form class="form-inline" id="searchForm" @submit.prevent="getSearchResult">
				<div class="form-group">
					<label>Search Type</label>
					<select class="form-control" v-model="searchType" @change="onChangeSearchType">
						<option value="">All</option>
						<option value="patient">By Patient</option>
						<option value="driver">By Driver</option>
						<option value="ambulance">By Ambulance</option>
					</select>
				</div>

				<div class="form-group" style="display:none;" v-bind:style="{display: searchType == 'patient' && patients.length > 0 ? '' : 'none'}">
					<label style="margin-top:5px;">Patient</label>
					<v-select v-bind:options="patients" v-model="selectedPatient" label="display_name"></v-select>
				</div>

				<div class="form-group" style="display:none;" v-bind:style="{display: searchType == 'driver' && drivers.length > 0 ? '' : 'none'}">
					<label style="margin-top:5px;">Driver</label>
					<v-select v-bind:options="drivers" v-model="selectedDriver" label="display_name"></v-select>
				</div>

				<div class="form-group" style="display:none;" v-bind:style="{display: searchType == 'ambulance' && ambulances.length > 0 ? '' : 'none'}">
					<label style="margin-top:5px;">Ambulance</label>
					<v-select v-bind:options="ambulances" v-model="selectedAmbulance" label="display_text"></v-select>
				</div>

			

				<div class="form-group">
					<input type="date" class="form-control" v-model="dateFrom">
				</div>

				<div class="form-group">
					<input type="date" class="form-control" v-model="dateTo">
				</div>

				<div class="form-group" style="margin-top: -5px;">
					<input type="submit" value="Search">
				</div>
			</form>
		</div>
	</div>

	<div class="row" style="margin-top:15px;display:none;" v-bind:style="{display: amulancebills.length > 0 ? '' : 'none'}">
		<div class="col-md-12" style="margin-bottom: 10px;">
			<a href="" @click.prevent="print"><i class="fa fa-print"></i> Print</a>
		</div>
		<div class="col-md-12">
			<div class="table-responsive" id="reportContent">
				<table 
					class="record-table" 
					v-if="searchTypesForRecord.includes(searchType)" 
					style="display:none" 
					v-bind:style="{display: searchTypesForRecord.includes(searchType)  ? '' : 'none'}"
					>
					<thead>
						<tr>
							<th>Invoice No.</th>
							<th>Date</th>
							<th>Driver</th>
							<th>Ambulance</th>
							<th>Patient</th>
							<th>Bill Amount</th>
							<th>Paid</th>
							<th>Due</th>
							<th>Destination</th>
							<th>Note</th>
							<th>Action</th>
						</tr>
					</thead>
					<tbody>
						<tr v-for="(amulancebill,sl) in amulancebills" :key='sl'>
								<td style="text-align: center;">{{ amulancebill.invoice_number }}</td>
                                <td style="text-align: center;">{{ amulancebill.bill_date }}</td>
                                <td>{{ amulancebill.driver_name }}</td>
                                <td>{{ amulancebill.ambulance_name }}</td>
                                <td>{{ amulancebill.patient_text }}</td>
                                <td style="text-align: center;">{{ amulancebill.bill_amount | decimal }}</td>
                                <td style="text-align: center;">{{ amulancebill.paid | decimal }}</td>
                                <td style="text-align: center;">{{ amulancebill.due | decimal }}</td>
                                <td>{{ amulancebill.destination }}</td>
                                <td>{{ amulancebill.remark }}</td>
								<td style="text-align:center;">
									<a title="Issue Invoice" v-bind:href="'/ambulancebill_invoice_print/'+ amulancebill.id" target="_blank"><i class="fa fa-file-text"></i></a>
								</td>
						</tr>
					</tbody>
					
				</table>

				
			</div>
		</div>
	</div>
</div>
</template>

<script>
import moment from 'moment';
export default {
    props: ['role'],
    data(){
			return {
				searchType: '',
				dateFrom: moment().format('YYYY-MM-DD'),
				dateTo: moment().format('YYYY-MM-DD'),
				patients: [],
				selectedPatient: null,
				drivers: [],
				selectedDriver: null,
				ambulances: [],
				selectedAmbulance: null,
				amulancebills: [],
				searchTypesForRecord: ['', 'driver', 'patient','ambulance']
			}
		},
        created(){
            this.getBranchInfo();
        },
		filters: {
            decimal(value) {
                    return value == null ? '0.00' : parseFloat(value).toFixed(2);
                }
        },
		methods: {
		
			onChangeSearchType(){
				this.amulancebills = [];
				if(this.searchType == 'ambulance'){
					this.getAmbulances();
				} 
				
				else if(this.searchType == 'driver'){
					this.getDrivers();
				}
				else if(this.searchType == 'patient'){
					this.getPatients();
				}
			},
            getBranchInfo(){
                axios.get('/get_branch_info').then(res=>{
                    this.branch = res.data;
                })
            },
			getAmbulances(){
				axios.get('/get_ambulances').then(res => {
					this.ambulances = res.data;
				})
			},
			getPatients(){
				axios.get('/get_patients').then(res => {
					this.patients = res.data;
				})
			},
			
			getDrivers(){
				axios.get('/get_drivers').then(res => {
					this.drivers = res.data;
				})
			},
			getSearchResult(){

				if(this.searchType != 'ambulance'){
					this.selectedAmbulance = null;
				}

				if(this.searchType != 'driver'){
					this.selectedDriver = null;
				}

				if(this.searchType != 'patient'){
					this.selectedPatient = null;
				}

				if(this.searchTypesForRecord.includes(this.searchType)) {
					this.getIssueRecord();
				} 
			},
			getIssueRecord(){
				let filter = {
					ambulanceId: this.selectedAmbulance == null ? '' : this.selectedAmbulance.id,
					driverId: this.selectedDriver == null ? '' : this.selectedDriver.id,
					patientId: this.selectedPatient == null ? '' : this.selectedPatient.id,
					dateFrom: this.dateFrom,
					dateTo: this.dateTo
				}

               

				let url = '/get_ambulancesbill';
				

				axios.post(url, filter)
				.then(res => {
						this.amulancebills = res.data;
				})
				.catch(error => {
					if(error.response){
						alert(`${error.response.status}, ${error.response.statusText}`);
					}
				})
			},
			
			async print(){
				let dateText = '';
				if(this.dateFrom != '' && this.dateTo != ''){
					dateText = `Statement from <strong>${this.dateFrom}</strong> to <strong>${this.dateTo}</strong>`;
				}

				let driverText = '';
				if(this.selectedDriver != null && this.selectedDriver.id != '' && this.searchType == 'driver'){
					driverText = `<strong>Sold by: </strong> ${this.selectedDriver.display_name}`;
				}

				let patientText = '';
				if(this.selectedPatient != null && this.selectedPatient.id != '' && this.searchType == 'patient'){
					patientText = `<strong>Patient: </strong> ${this.selectedPatient.name}<br>`;
				}

				let ambulanceText = '';
				if(this.selectedAmbulance != null && this.selectedAmbulance.id != '' && this.searchType == 'ambulance'){
					ambulanceText = `<strong>Product: </strong> ${this.selectedAmbulance.display_text}`;
				}

			


				let reportContent = `
					<div class="container">
						<div class="row">
							<div class="col-xs-12 text-center">
								<h3>Issue Record</h3>
							</div>
						</div>
						<div class="row">
							<div class="col-xs-6">
								${patientText} ${driverText} ${ambulanceText}
							</div>
							<div class="col-xs-6 text-right">
								${dateText}
							</div>
						</div>
						<div class="row">
							<div class="col-xs-12">
								${document.querySelector('#reportContent').innerHTML}
							</div>
						</div>
					</div>
				`;

				var reportWindow = window.open('', 'PRINT', `height=${screen.height}, width=${screen.width}`);
				reportWindow.document.write(`
                <link rel="stylesheet" href="/assets/css/bootstrap.min.css">
                <div class="container">
                    <div class="row">
                        <div class="col-xs-2"><img src="${this.branch.logo}" alt="Logo" style="height:80px;" /></div>
                        <div class="col-xs-10" style="padding-top:20px;">
                            <strong style="font-size:18px;">${this.branch.name}</strong><br>
                            <p style="white-space: pre-line;">${this.branch.address}</p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-xs-12">
                            <div style="border-bottom: 4px double #454545;margin-top:7px;margin-bottom:7px;"></div>
                        </div>
                    </div>
                </div>
            `);

				reportWindow.document.head.innerHTML += `
					<style>
						.record-table{
							width: 100%;
							border-collapse: collapse;
						}
						.record-table thead{
							background-color: #0097df;
							color:white;
						}
						.record-table th, .record-table td{
							padding: 3px;
							border: 1px solid #454545;
						}
						.record-table th{
							text-align: center;
						}
					</style>
				`;
				reportWindow.document.body.innerHTML += reportContent;

				if(this.searchType == '' || this.searchType == 'user'){
					let rows = reportWindow.document.querySelectorAll('.record-table tr');
					rows.forEach(row => {
						row.lastChild.remove();
					})
				}


				reportWindow.focus();
				await new Promise(resolve => setTimeout(resolve, 1000));
				reportWindow.print();
				reportWindow.close();
			}
		}

}
</script>