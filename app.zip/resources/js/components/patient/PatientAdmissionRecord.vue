<style scoped>

	#searchForm select{
		padding:0;
		border-radius: 4px;
	}
	#searchForm .form-group{
		margin-right: 5px;
	}
	#searchForm *{
		font-size: 13px;
	}

	
	th{
		background-color: #146C94;
	color:#fff !important;
	}
	.table-responsive tr{
		background-color: #E3F4F4 !important;
	-webkit-transition: .5s all;   
		-webkit-transition-delay: .05s; 
		-moz-transition: .5s all;   
		-moz-transition-delay: .05s; 
		-ms-transition: .5s all;   
		-ms-transition-delay: .05s; 
		-o-transition: .5s all;   
		-o-transition-delay: .05s; 
		transition: .5s all;   
		transition-delay: .05s; 
	}
	.table-responsive tr:hover{
	background-color: #62CDFF !important;
	transition: 0s all;   
	-webkit-transition-delay: 0s;
		-moz-transition-delay: 0s;
		-ms-transition-delay: 0s;
		-o-transition-delay: 0s;
		transition-delay: 0s;
}
</style>
<template>
<div>
	<div class="row" style="border-bottom: 1px solid #ccc;padding: 3px 0;">
		<div class="col-md-12">
			<form class="form-inline" id="searchForm" @submit.prevent="getPurchaseRecord">
				<div class="form-group">
					<label>Search Type</label>
					<select class="form-control" v-model="searchType" >
						<option value="">All</option>
						<option value="Admited">Admited</option>
						<option value="Release">Release</option>
					</select>
				</div>
				<div class="form-group">
					<input type="date" class="form-control" v-model="dateFrom">
				</div>
				<div class="form-group">
					<input type="date" class="form-control" v-model="dateTo">
				</div>

				<div class="form-group" style="margin-top: -5px;">
					<input type="submit" value="Search">
				</div>
			</form>
		</div>
	</div>

	<div class="row" style="margin-top:15px;display:none;" v-bind:style="{display: patientadmissions.length > 0 ? '' : 'none'}">
		<div class="col-md-12" style="margin-bottom: 10px;">
			<a href="" @click.prevent="print"><i class="fa fa-print"></i> Print</a>
		</div>
		<div class="col-md-12">
			<div class="table-responsive" id="reportContent">
				<table class="record-table" >
					<thead>
						<tr>
							<th>Admission No.</th>
							<th>Date</th>
							<th>Name</th>
							<th>Mobile</th>
							<th>Address</th>
							<th style="font-size: 12px;">Date of Birth</th>
							<th>Age</th>
							<th>Gender</th>
							<th>Doctor</th>
							<th>Referance</th>
							<th>Room</th>
							<th>Seat</th>
							<th style="background-color: #5D3891;">Status</th>
							<th style="background-color:#FF6E31;color: #fff;font-size: 12px; width:80px;">Is Seat Shift</th>
							<th>Note</th>
						</tr>
					</thead>
					<tbody>
						<tr v-for="(patientadmission,sl) in patientadmissions" :key='sl'>
							<td>{{ patientadmission.admission_code }}</td>
							<td>{{ patientadmission.admission_date }}</td>
							<td>{{ patientadmission.patient_name }}</td>
							<td>{{ patientadmission.patient_mobile }}</td>
							<td>{{ patientadmission.patient_date_of_birth }}</td>
							<td>{{ patientadmission.patient_age }}</td>
							<td>{{ patientadmission.patient_gender }}</td>
							<td>{{ patientadmission.doctor_display_name }}</td>
							<td>{{ patientadmission.reference_display_name }}</td>
							<td>{{ patientadmission.reference_display_name }}</td>
							<td>{{ patientadmission.room_name }}</td>
							<td>{{ patientadmission.bed_number }}</td>
							<td class="text-center" v-if="patientadmission.status=='Admited'">
								<span class="badge bg-success" style="background-color: #367E18;">Admited</span>
							</td>
							<td class="text-center" v-if="patientadmission.status=='Release'">
								<span class="badge bg-danger" style="background-color: #DC3535;">Release</span>
							</td>
							<td class="text-center" v-if="patientadmission.is_shift==0">
								<span class="badge bg-success" style="background-color: #DC3535;">No</span>
							</td>
							<td class="text-center"  v-if="patientadmission.is_shift==1">
								<span class="badge bg-danger" style="background-color: #367E18;">Yes</span>
							</td>
							<td style="text-align:left;">{{ patientadmission.remark }}</td>
						</tr>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>
</template>

<script>
import moment from 'moment';
export default {
    props: ['role'],
    data(){
			return {
				searchType: '',
				dateFrom: moment().format('YYYY-MM-DD'),
				dateTo: moment().format('YYYY-MM-DD'),
				patientadmissions: []
			}
		},
        created(){
            this.getBranchInfo();
        },
		methods: {
			
            getBranchInfo(){
                axios.get('/get_branch_info').then(res=>{
                    this.branch = res.data;
                })
            },
			
			getPurchaseRecord(){
				let filter = {
					status: this.searchType ? this.searchType : null,
					dateFrom: this.dateFrom,
					dateTo: this.dateTo
				}

             
				let url = '/get_admissions';
				

				axios.post(url, filter)
				.then(res => {
						this.patientadmissions = res.data;
				})
				.catch(error => {
					if(error.response){
						alert(`${error.response.status}, ${error.response.statusText}`);
					}
				})
			},
			
			async print(){
				let dateText = '';
				if(this.dateFrom != '' && this.dateTo != ''){
					dateText = `Statement from <strong>${this.dateFrom}</strong> to <strong>${this.dateTo}</strong>`;
				}

				let reportContent = `
					<div class="container">
						<div class="row">
							<div class="col-xs-12 text-center">
								<h3>Purchase Record</h3>
							</div>
						</div>
						<div class="row">
							<div class="col-xs-6">
								
							</div>
							<div class="col-xs-6 text-right">
								${dateText}
							</div>
						</div>
						<div class="row">
							<div class="col-xs-12">
								${document.querySelector('#reportContent').innerHTML}
							</div>
						</div>
					</div>
				`;

				var reportWindow = window.open('', 'PRINT', `height=${screen.height}, width=${screen.width}`);
				reportWindow.document.write(`
                <link rel="stylesheet" href="/assets/css/bootstrap.min.css">
                <div class="container">
                    <div class="row">
                        <div class="col-xs-2"><img src="${this.branch.logo}" alt="Logo" style="height:80px;" /></div>
                        <div class="col-xs-10" style="padding-top:20px;">
                            <strong style="font-size:18px;">${this.branch.name}</strong><br>
                            <p style="white-space: pre-line;">${this.branch.address}</p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-xs-12">
                            <div style="border-bottom: 4px double #454545;margin-top:7px;margin-bottom:7px;"></div>
                        </div>
                    </div>
                </div>
            `);

				reportWindow.document.head.innerHTML += `
					<style>
						.record-table{
							width: 100%;
							border-collapse: collapse;
						}
						.record-table thead{
							background-color: #0097df;
							color:white;
						}
						.record-table th, .record-table td{
							padding: 3px;
							border: 1px solid #454545;
						}
						.record-table th{
							text-align: center;
						}
					</style>
				`;
				reportWindow.document.body.innerHTML += reportContent;

				// if(this.searchType == ''){
				// 	let rows = reportWindow.document.querySelectorAll('.record-table tr');
				// 	rows.forEach(row => {
				// 		row.lastChild.remove();
				// 	})
				// }


				reportWindow.focus();
				await new Promise(resolve => setTimeout(resolve, 1000));
				reportWindow.print();
				reportWindow.close();
			}
		}

}
</script>