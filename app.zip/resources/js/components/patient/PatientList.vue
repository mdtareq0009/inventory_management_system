<style scoped>
	th{
		background-color: #146C94;
	color:#fff !important;
	}
	.table-responsive tr{
		background-color: #E3F4F4 !important;
	-webkit-transition: .5s all;   
		-webkit-transition-delay: .05s; 
		-moz-transition: .5s all;   
		-moz-transition-delay: .05s; 
		-ms-transition: .5s all;   
		-ms-transition-delay: .05s; 
		-o-transition: .5s all;   
		-o-transition-delay: .05s; 
		transition: .5s all;   
		transition-delay: .05s; 
	}
	.table-responsive tr:hover{
	background-color: #62CDFF !important;
	transition: 0s all;   
	-webkit-transition-delay: 0s;
		-moz-transition-delay: 0s;
		-ms-transition-delay: 0s;
		-o-transition-delay: 0s;
		transition-delay: 0s;
}
</style>
<template>
    <div>
        <div class="row" style="border-bottom: 1px solid #ccc;padding: 3px 0;">
		<div class="col-md-12">
			<form class="form-inline" id="searchForm" @submit.prevent="getPatientRecord">
				<div class="form-group">
					<label>Search Type</label>
					<select class="form-control" v-model="searchType" @change="onChangeSearchType">
						<option value="">All</option>
						<option value="name">By Name</option>
						<option value="pgender">By Gender</option>
						<option value="mobile">By Mobile</option>
					</select>
				</div>
                <div class="form-group" style="display:none;" v-bind:style="{display: searchType == 'name' ? '' : 'none'}">
					<label style="margin-top:5px;">Patient Name</label>
					<input type="text" class="form-control" v-model="pname">
				</div>
                <div class="form-group" style="display:none;" v-bind:style="{display: searchType == 'mobile' ? '' : 'none'}">
					<label style="margin-top:5px;">Mobile Name</label>
					<input type="text" class="form-control" v-model="mobileno">
				</div>
                <div class="form-group" style="display:none;" v-bind:style="{display: searchType == 'pgender' ? '' : 'none'}">
					<label style="margin-top:5px;">Gender</label>
                    <select class="form-control" v-model="gender">
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>
                                <option value="Other">Other</option>
                    </select>
				</div>
				<div class="form-group" style="margin-top: -5px;">
					<input type="submit" value="Search">
				</div>
			</form>
		</div>
	</div>
        <div class="row" style="margin-top:15px;display:none;" v-bind:style="{display: patients.length > 0 ? '' : 'none'}">
            <div class="col-md-12" style="margin-bottom: 10px;">
			<a href="" @click.prevent="print"><i class="fa fa-print"></i> Print</a>
		    </div>
            <div class="col-md-12">
                <div class="table-responsive" id="reportContent">
                    <table class="record-table" 
					v-if="(searchTypesForRecord.includes(searchType))" 
					style="display:none" 
					v-bind:style="{display: (searchTypesForRecord.includes(searchType))? '' : 'none'}"
					>
                        <thead>
                            <tr>
                                <th>Code</th>
                                <th>Patient Name</th>
                                <th>Mobile</th>
                                <th>Gender</th>
                                <th>Date of birth</th>
                                <th>Age</th>
                                <th>Address</th>
                                <th>Remark</th>
                            </tr>
                        </thead>        
                        <tbody>
                            <tr v-for="(row,sl) in patients" :key='sl'>
                                    <td>{{ row.patient_code }}</td>
                                    <td>{{ row.name }}</td>
                                    <td>{{ row.mobile }}</td>
                                    <td>{{ row.gender }}</td>
                                    <td>{{ row.date_of_birth }}</td>
                                    <td>{{ row.age }}</td>
                                    <td>{{ row.address }}</td>
                                    <td>{{ row.remark }}</td>
                            </tr>
                        </tbody>
				    </table>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import moment from 'moment';
export default {
    props: ['role'],
    data(){
			return {
				searchType: '',
				pname: '',
				gender: [],
				mobileno: '',
                patients: [],
				searchTypesForRecord: ['', 'name', 'pgender','mobile'],
			}
		},
        created(){
            this.getBranchInfo();
        },
		methods: {
	
			onChangeSearchType(){
				this.patients = [];
                this.pname= '';
				this.gender= '';
				this.mobileno= '';
			},
            getBranchInfo(){
                axios.get('/get_branch_info').then(res=>{
                    this.branch = res.data;
                })
            },
			
			getSearchResult(){
				if(this.searchTypesForRecord.includes(this.searchType)) {
					this.getPatientRecord();
				} 
			},
			getPatientRecord(){
                if(this.searchType == 'name' && this.pname == ''){
					alert("Type Patient Name");
                    return;
				}

				if(this.searchType == 'gender' && this.gender == ''){
					alert("Select Gender");
                    return;
				}

				if(this.searchType == 'mobile' && this.mobileno == ''){
					alert("Type Mobile No.");
                    return;
				}

				let filter = {
					gender: this.gender == '' ? '' : this.gender,
					pname: this.pname == '' ? '' : this.pname,
					mobile: this.mobileno == '' ? '' : this.mobileno,
				}


				let url = '/get_patients';
				

				axios.post(url, filter)
				.then(res => {
						this.patients = res.data;
				})
				.catch(error => {
					if(error.response){
						alert(`${error.response.status}, ${error.response.statusText}`);
					}
				})
			},
	
			async print(){
                let nameText = '';
				if(this.searchType == 'name' && this.pname != ''){
					nameText = `<strong>Name Match by: </strong> ${this.pname}`;
				}

				let mobileText = '';
				if(this.searchType == 'mobile' && this.mobileno != ''){
					mobileText = `<strong>Mobile no By: </strong> ${this.mobileno}<br>`;
				}

				let gendertText = '';
				if(this.searchType == 'gender' && this.gender != ''){
					gendertText = `<strong>Gender: </strong> ${this.gender}`;
				}
				let allText = '';
				if(this.searchType == ''){
					gendertText = `<strong>All Patient</strong>`;
				}

				



				let reportContent = `
					<div class="container">
						<div class="row">
							<div class="col-xs-12 text-center">
								<h3>Patient List</h3>
							</div>
						</div>
						<div class="row">
							<div class="col-xs-12 text-center">
								${allText} ${nameText} ${mobileText} ${gendertText}
							</div>
						</div>
						<div class="row">
							<div class="col-xs-12">
								${document.querySelector('#reportContent').innerHTML}
							</div>
						</div>
					</div>
				`;

				var reportWindow = window.open('', 'PRINT', `height=${screen.height}, width=${screen.width}`);
				reportWindow.document.write(`
                <link rel="stylesheet" href="/assets/css/bootstrap.min.css">
                <div class="container">
                    <div class="row">
                        <div class="col-xs-2"><img src="${this.branch.logo}" alt="Logo" style="height:80px;" /></div>
                        <div class="col-xs-10" style="padding-top:20px;">
                            <strong style="font-size:18px;">${this.branch.name}</strong><br>
                            <p style="white-space: pre-line;">${this.branch.address}</p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-xs-12">
                            <div style="border-bottom: 4px double #454545;margin-top:7px;margin-bottom:7px;"></div>
                        </div>
                    </div>
                </div>
            `);

				reportWindow.document.head.innerHTML += `
					<style>
						.record-table{
							width: 100%;
							border-collapse: collapse;
						}
						.record-table thead{
							background-color: #0097df;
							color:white;
						}
						.record-table th, .record-table td{
							padding: 3px;
							border: 1px solid #454545;
						}
						.record-table th{
							text-align: center;
						}
					</style>
				`;
				reportWindow.document.body.innerHTML += reportContent;

				if(this.searchType == '' || this.searchType == 'user'){
					let rows = reportWindow.document.querySelectorAll('.record-table tr');
					rows.forEach(row => {
						row.lastChild.remove();
					})
				}


				reportWindow.focus();
				await new Promise(resolve => setTimeout(resolve, 1000));
				reportWindow.print();
				reportWindow.close();
			}
		}

}
</script>
