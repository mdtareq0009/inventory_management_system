<style scoped>
 label{
    font-size: 13px !important;
 }
.no-padding-right{
	padding: 0px !important;
}
.widget-box{
	margin:0px !important;
	border: 0px solid #fff !important;
}
.widget-header{
	border: 1px solid #ccc !important; 
	min-height: 26px !important; 
	background: #146C94 !important; 
	color:aliceblue !important; 
	font-weight: bolder !important;
    
}
.widget-body{
    padding-left:10px !important;
}
.widget-title{
	line-height: 25px !important;
}

td{
    border: 1px solid #9DB2BF;
}
th{
		background-color: #146C94;
	color:#fff !important;
	}

.table-responsive .hover-tr{
    background-color: #E3F4F4 !important;
}

</style>
<template>
    <div>
        <form @submit.prevent="save">
            <div class="row">
                <div class="col-xs-12 col-md-10 col-lg-10 col-md-offset-1">
                    <div class="widget-box">
                        <div class="widget-header">
                            <h5 class="widget-title">Patient Payment Information</h5>
                        </div>
                        <div class="widget-body" style="background-color: #AEE2FF;">
                            <div class="widget-main">
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="form-group row">
                                            <label class="col-xs-4 control-label no-padding-right"> Transaction No. </label>
                                            <div class="col-xs-8">
                                                <input type="text" placeholder="Transaction No." class="form-control" v-model="patientpayment.transaction_number" readonly/>
                                            </div>
                                        </div>
                                       
                                        <div class="form-group row">
                                            <label class="col-xs-4 control-label no-padding-right"> Payment Type </label>
                                            <div class="col-xs-8">
                                                        <select class="form-control" v-model="patientpayment.payment_type" required>
                                                            <option value="Cash">Cash</option>
                                                            <option value="Bank">Bank</option>
                                                        </select>
                                            </div>
                                            </div>
                                            <div class="form-group row" style="display:none;" v-bind:style="{display: patientpayment.payment_type == 'Bank' ? '' : 'none'}">
                                                    <label class="col-xs-4 control-label no-padding-right">Bank Account</label>
                                                    <div class="col-xs-7">
                                                        <v-select v-bind:options="bankaccounts" class="select"  v-model="selectedBankAccount" label="display_name" placeholder="Select account"></v-select>
                                                    </div>
                                                    <div class="col-xs-1" style="padding: 0; margin-left: -10px;">
                                                        <a href="/bank_account_entry" target="_blank" class="add-button"><i class="fa fa-plus"></i></a>
                                                    </div>
                                            </div>
                                        <div class="form-group row">
                                            <label class="col-xs-4 control-label no-padding-right"> Patient </label>
                                            <div class="col-xs-7">
                                                <v-select :options="patients" class="select" v-model="selectedPatient" label="display_name" v-on:input="onChangeSupplier"></v-select>
                                            </div>
                                            <div class="col-xs-1" style="padding: 0; margin-left: -10px;">
                                                        <a href="/supplier_pharmacy_entry" target="_blank" class="add-button"><i class="fa fa-plus"></i></a>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-xs-4 control-label no-padding-right"> Transaction Type </label>
                                            <div class="col-xs-8">
                                                <select class="form-control"  v-model="patientpayment.transaction_type">
                                                    <option value="Received">Received</option>
                                                    <option value="Payment" selected>Payment</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-xs-4 control-label no-padding-right"> Due </label>
                                            <div class="col-xs-8">
                                                <input type="number" step="any" placeholder="Due"  class="form-control" v-model="patientpayment.previous_due" readonly />
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="form-group row">
                                            <label class="col-xs-3 control-label no-padding-right"> Date </label>
                                            <div class="col-xs-9">
                                                <input type="date" placeholder="Transaction Date" class="form-control" v-model="patientpayment.payment_date" @change="getPatientPaymentTransaction()" />
                                            </div>
                                        </div>
                                         <div class="form-group row">
                                            <label class="col-xs-3 control-label no-padding-right"> Note </label>
                                            <div class="col-xs-9">
                                                <textarea name="Remarks" id="" class="form-control" cols="5" rows="2" v-model="patientpayment.remark" placeholder="Remarks"></textarea>
                                            </div>
                                        </div>
                                          <div class="form-group row">
                                            <label class="col-xs-3 control-label no-padding-right"> Amount </label>
                                            <div class="col-xs-9">
                                                <input type="number" step="any" placeholder="Amount"  class="form-control" v-model="patientpayment.amount" />
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <div class="col-xs-4 col-xs-offset-8">
                                                <input
                                                    type="submit"
                                                    class="btn btn-primary btn-sm"
                                                    value="Save"
                                                    v-bind:disabled="progress ? true : false"
                                                    style="color: #fff !important; margin-top: 0px; width: 100%; padding: 5px; font-weight: bold;"
                                                />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
        <br />
        <div class="row">
            <div class="col-sm-12 form-inline">
                <div class="form-group">
                    <input type="text" class="form-control" v-model="filter" placeholder="Filter" />
                </div>
            </div>
            <div class="col-md-12">
                <div class="table-responsive">
                    <datatable class="table table-hover table-bordered" :columns="columns" :data="patientpayments" :filter="filter" :per-page="per_page">
                        <template slot-scope="{ row,index }">
                            <tr class="hover-tr">
                                <td>{{ index+1 }}</td>
                                <td>{{ row.payment_date }}</td>
                                <td>{{ row.transaction_number }}</td>
                                <td>{{ row.patient_text }}</td>
                                <td>{{ row.payment_type }}</td>
                                <td>
                                    <span v-if="row.display_text == ''"> N/A  </span>
                                    <span v-else>  {{ row.display_text}} </span>
                                </td>
                                <td>{{ row.transaction_type }}</td>
                                <td>{{ row.amount }}</td>
                                <td>{{ row.remark }}</td>
                              
                                <td>
                                    <span v-if="role != 'User'">
                                        <a class="blue" href="javascript:" @click="editPatientPayment(row)">
                                            <i class="ace-icon fa fa-pencil bigger-130"></i>
                                        </a>
                                        <a class="red" href="javascript:" @click="deletePatientPayment(row.id)">
                                            <i class="ace-icon fa fa-trash bigger-130"></i>
                                        </a>
                                    </span>
                                </td>
                            </tr>
                        </template>
                    </datatable>
                    <datatable-pager class="datatable-pagination" v-model="page" type="abbreviated"></datatable-pager>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
import moment from 'moment';
export default {
    props: ['role'],
    data () {

        return {
            patientpayment: {
                id                : '',
                transaction_number: '',
                account_id        : '',
                supplier_id       : '',
                payment_date      : moment().format('YYYY-MM-DD'),
                transaction_type  : 'Received',
                payment_type      : 'Cash',
                amount            : 0,
                previous_due      : 0,
                remark            : '',
            },

            patientpayments: [],
            bankaccounts: [],
            selectedBankAccount: null,
            patients: [],
            selectedPatient: null,
            columns     : [
                { label: 'S/L No.', field: 'sl_no', align: 'center'},
                { label: 'Transaction date', field: 'payment_date', align: 'center' },
                { label: 'Transaction number', field: 'transaction_number', align: 'center' },
                { label: 'Patient', field: 'patient_text', align: 'center' },
                { label: 'Payment Type', field: 'payment_type', align: 'center' },
                { label: 'Account Name', field: 'display_text', align: 'center' },
                { label: 'Transaction Type', field: 'transaction_type', align: 'center' },
                { label: 'Amount', field: 'amount', align: 'center' },
                { label: 'Note', field: 'remark', align: 'center' },
                { label: 'Action', align: 'center', filterable: false }
            ],
            page: 1,
            per_page: 10,
            filter: '',
            progress: false
        }
    },
   
    created(){
        this.getBankAccount();
        this.getPatients();
        this.getPatientPaymentTransaction();
        this.getPatientPaymentTransactionCode();
    },
    methods: {
        
        getBankAccount(){
            axios.get('/get_bankaccounts').then(res=>{
                this.bankaccounts = res.data;
            })
        },
        getPatients(){
            axios.get('/get_patients').then(res=>{
                this.patients = res.data;
            })
        },
        onChangeSupplier(){
				axios.post('/get_madicine_patient_due', {patientId: this.selectedPatient.id}).then(res => {
					if(res.data.getDues.length > 0){
						this.patientpayment.previous_due = res.data.getDues[0].due;
					} else {
						this.patientpayment.previous_due = 0;
					}
				})
			},
      
        getPatientPaymentTransaction(){
            axios.post('/get_patient_payments_medicine',{date: this.patientpayment.payment_date}).then(res=>{
                this.patientpayments = res.data;
            })
        },
        getPatientPaymentTransactionCode(){
            axios.get('/get_patient_payment_medicine_code').then(res=>{
                this.patientpayment.transaction_number = res.data;
            })
        },

        save(){

            if(this.selectedPatient == null){
                alert('Select Patient');
                return;
            }
            if(this.patientpayment.previous_due < this.patientpayment.amount || this.patientpayment.amount==0){
                alert('Please Amount is over due OR Zero Amount');
                return;
            }
            this.progress = true;

            if(this.patientpayment.payment_type == 'Cash'){

                this.patientpayment.account_id  = null;
            }else{
                this.patientpayment.account_id  = this.selectedBankAccount.id;
            }


            this.patientpayment.patient_id = this.selectedPatient.id;

            let url = '/store-patientpayment-medicine';
            if(this.patientpayment.id != ''){
                url = '/update-patientpayment-medicine';
            }
            let data = {
                patientpayment: this.patientpayment
			}
            
            axios.post(url, data).then(res=>{
                this.progress = false;
                this.$toaster.success(res.data.message);
                this.clear();
                this.getPatients();
                this.getBankAccount();
                this.getPatientPaymentTransaction();
                this.getPatientPaymentTransactionCode();
            }).catch(error=>{
                this.progress = false;
                let e = error.response.data;
                if(e.hasOwnProperty('message')){
                    this.$toaster.error(e.message);
                }else{
                    Object.entries(e).forEach(([key, val])=>{
                        this.$toaster.error(val[0]);
                    })
                }
            })
        },
        clear(){
            this.patientpayment = {
                 id                : '',
                 transaction_number: '',
                 account_id        : '',
                 payment_date      : moment().format('YYYY-MM-DD'),
                 transaction_type  : 'Received',
                 amount            : 0,
                 previous_due      : 0,
                 remark            : '',
            };
            this.bankaccounts        = [];
            this.selectedBankAccount = null;
            this.selectedPatient    = null;
        },
        
     
        editPatientPayment(row){
            this.patientpayment = {
                id                : row.id,
                transaction_number: row.transaction_number,
                patient_id        : row.patient_id,
                account_id        : row.account_id,
                payment_date      : row.payment_date,
                payment_type      : row.payment_type,
                transaction_type  : row.transaction_type,
                amount            : row.amount,
                previous_due      : row.previous_due,
                remark            : row.remark,
            }

            this.selectedBankAccount = {
                id          : row.account_id,
                display_name: row.display_text
            }
            this.selectedPatient = {
                id          : row.patient_id,
                display_name: row.patient_text
            }

        },
        deletePatientPayment(id){
            Swal.fire({
                title: '<strong>Are you sure!</strong>',
                html: '<strong>Want to delete this?</strong>',
                customClass: 'swal-wide',
                showDenyButton: true,
                confirmButtonText: `Ok`,
                denyButtonText: `Cancel`,
            }).then((result) => {
                if (result.isConfirmed) {
                    axios.post('/delete-patientpayment-medicine', {id}).then(res=>{
                        let r = res.data;
                        Swal.fire({
                            icon: 'success',
                            title: r.message,
                            showConfirmButton: false,
                            timer: 1500
                        })
                        this.clear();
                        this.getPatients();
                        this.getBankAccount();
                        this.getPatientPaymentTransaction();
                        this.getPatientPaymentTransactionCode();
                    }).catch(error => {
                        let e = error.response.data;

                        if(e.hasOwnProperty('message')){
                            if(e.hasOwnProperty('errors')){
                                Object.entries(e.errors).forEach(([key, val])=>{
                                    this.$toaster.error(val[0]);
                                })
                            }else{
                                this.$toaster.error(e.message);
                            }
                        }else{
                            this.$toaster.error(e);
                        }
                    })
                }
            })
        }
    }
}
</script>