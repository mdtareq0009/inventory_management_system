@extends('layouts.admin')
@section('title', 'Cash Ledger')
@section('breadcrumb', 'Cash Ledger')
@section('body')

<cash-in-out-report role="{{ auth()->user()->role }}"></cash-in-out-report>

@endsection
