@extends('layouts.admin')
@section('title', 'Commission Payment')
@section('breadcrumb', 'Commission Payment')
@section('body')

<commission-payment role="{{ auth()->user()->role }}"></commission-payment>

@endsection