@extends('layouts.admin')
@section('title', 'Commission ledger')
@section('breadcrumb', 'Commission ledger')
@section('body')

<commission-payment-ledger></commission-payment-ledger>

@endsection