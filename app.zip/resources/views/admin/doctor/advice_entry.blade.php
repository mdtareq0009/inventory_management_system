@extends('layouts.admin')
@section('title', 'Advice Entry')
@section('breadcrumb', 'Advice Entry')
@section('body')

<advice-entry></advice-entry>

@endsection