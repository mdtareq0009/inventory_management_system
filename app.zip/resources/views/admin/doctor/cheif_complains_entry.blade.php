@extends('layouts.admin')
@section('title', 'Cheif Complains Entry')
@section('breadcrumb', 'Cheif Complains Entry')
@section('body')

<cheif-complains-entry></cheif-complains-entry>

@endsection