@extends('layouts.admin')
@section('title', 'Dose Entry')
@section('breadcrumb', 'Dose Entry')
@section('body')

<dose-entry></dose-entry>

@endsection