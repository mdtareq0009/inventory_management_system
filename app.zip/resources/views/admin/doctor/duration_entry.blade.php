@extends('layouts.admin')
@section('title', 'Duration Entry')
@section('breadcrumb', 'Duration Entry')
@section('body')

<duration-entry></duration-entry>

@endsection