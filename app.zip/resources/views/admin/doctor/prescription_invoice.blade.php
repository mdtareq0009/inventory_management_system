@extends('layouts.admin')
@section('title', 'Prescription Invoice')
@section('breadcrumb', 'Prescription Invoice')
@section('body')

<prescription-invoice id="{{$id}}"></prescription-invoice>

@endsection