@extends('layouts.admin')
@section('title', 'Prescription Record')
@section('breadcrumb', 'Prescription Record')
@section('body')

<prescription-record></prescription-record>

@endsection