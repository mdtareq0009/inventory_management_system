@extends('layouts.admin')
@section('title', 'Graph')
@section('breadcrumb', 'Graph')
@section('body')

<graph-report></graph-report>

@endsection
