@extends('layouts.admin')
@section('title', 'Inventory Damage List')
@section('breadcrumb', 'Inventory Damage List')
@section('body')

<damage-inventory-list></damage-inventory-list>

@endsection