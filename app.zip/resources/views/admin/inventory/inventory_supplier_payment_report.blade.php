@extends('layouts.admin')
@section('title', 'Inventory Supplier Payment Report')
@section('breadcrumb', 'Inventory Supplier Payment Report')
@section('body')

<supplier-payment-inventory-report></supplier-payment-inventory-report>

@endsection