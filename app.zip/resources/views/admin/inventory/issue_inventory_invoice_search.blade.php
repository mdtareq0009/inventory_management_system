@extends('layouts.admin')
@section('title', 'Inventory Issue Invoice')
@section('breadcrumb', 'Inventory Issue Invoice')
@section('body')



<issue-inventory-invoice-search></issue-inventory-invoice-search>




@endsection