@extends('layouts.admin')
@section('title', 'Inventory Purchase Invoice')
@section('breadcrumb', 'Inventory Purchase Invoice')
@section('body')

<purchase-inventory-invoice id="{{$id}}"></purchase-inventory-invoice>

@endsection