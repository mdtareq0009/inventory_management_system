@extends('layouts.admin')
@section('title', 'Inventory purchase return invoice')
@section('breadcrumb', 'Invoice purchase return invoice')
@section('body')

<purchase-return-inventory-invoice id="{{$id}}"></purchase-return-inventory-invoice>

@endsection