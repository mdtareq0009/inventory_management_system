@extends('layouts.admin')
@section('title', 'Ambulance Bill Invoice')
@section('breadcrumb', 'Ambulance Bill Invoice')
@section('body')

<ambulance-bill-invoice id="{{$id}}"></ambulance-bill-invoice>

@endsection