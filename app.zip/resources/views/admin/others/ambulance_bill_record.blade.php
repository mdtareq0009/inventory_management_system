@extends('layouts.admin')
@section('title', 'Ambulance Bill Record')
@section('breadcrumb', 'Ambulance Bill Record')
@section('body')

<ambulance-bill-record></ambulance-bill-record>

@endsection