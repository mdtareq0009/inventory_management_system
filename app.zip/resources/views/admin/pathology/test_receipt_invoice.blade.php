@extends('layouts.admin')
@section('title', 'Test Receipt Invoice')
@section('breadcrumb', 'Test Receipt  Invoice')
@section('body')

<test-receipt-invoice id="{{$id}}"></test-receipt-invoice>

@endsection