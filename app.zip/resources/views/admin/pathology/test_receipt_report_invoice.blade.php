@extends('layouts.admin')
@section('title', 'Test Receipt Report')
@section('breadcrumb', 'Test Receipt Report')
@section('body')

<test-receipt-report-invoice id="{{$id}}"></test-receipt-report-invoice>

@endsection