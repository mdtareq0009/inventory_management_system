@extends('layouts.admin')
@section('title', 'Appointment Report')
@section('breadcrumb', 'Appointment Report')
@section('body')

<appointment-report role="{{ auth()->user()->role }}"></appointment-report>

@endsection