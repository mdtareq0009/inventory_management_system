@extends('layouts.admin')
@section('title', 'Appointment Token')
@section('breadcrumb', 'Appointment Token')
@section('body')

<appointment-token id="{{$id}}"></appointment-token>

@endsection