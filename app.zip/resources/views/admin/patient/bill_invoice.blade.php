@extends('layouts.admin')
@section('title', 'Bill Invoice')
@section('breadcrumb', 'Bill Invoice')
@section('body')

<bill-invoice id="{{$id}}"></bill-invoice>

@endsection