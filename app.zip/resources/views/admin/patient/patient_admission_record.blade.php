@extends('layouts.admin')
@section('title', 'Patient Admission Record')
@section('breadcrumb', 'Patient Admission Record')
@section('body')

<patient-admission-record></patient-admission-record>

@endsection