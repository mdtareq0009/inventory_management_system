@extends('layouts.admin')
@section('title', 'Bill Payment Search')
@section('breadcrumb', 'Bill Payment Search')
@section('body')

<slip-bill-payment-search></slip-bill-payment-search>

@endsection