@extends('layouts.admin')
@section('title', 'Slip Bill Search')
@section('breadcrumb', 'Slip Bill Search')
@section('body')

<slip-bill-search></slip-bill-search>

@endsection