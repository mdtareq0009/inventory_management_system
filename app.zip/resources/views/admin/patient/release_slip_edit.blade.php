@extends('layouts.admin')
@section('title', 'Release Slip Edit')
@section('breadcrumb', 'Release Slip Edit')
@section('body')

<release-slip-edit id="{{$id}}"></release-slip-edit>

@endsection