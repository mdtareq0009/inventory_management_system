@extends('layouts.admin')
@section('title', 'Seat Status')
@section('breadcrumb', 'Seat Status')
@section('body')

<seat-status></seat-status>

@endsection