@extends('layouts.admin')
@section('title', 'Patient Due List')
@section('breadcrumb', 'Patient Due List')
@section('body')

<patient-due-report role="{{ auth()->user()->role }}"></Patient-due-report>

@endsection
