@extends('layouts.admin')
@section('title', 'Patient Due Collection')
@section('breadcrumb', 'Patient Due Collection')
@section('body')

<patient-payment-medicine role="{{ auth()->user()->role }}"></patient-payment-medicine>

@endsection