@extends('layouts.admin')
@section('title', 'Supplier Payment Report')
@section('breadcrumb', 'Supplier Payment Report')
@section('body')

<supplier-payment-medicine-report></supplier-payment-medicine-report>

@endsection