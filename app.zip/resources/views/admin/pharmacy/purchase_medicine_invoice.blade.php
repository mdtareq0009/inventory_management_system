@extends('layouts.admin')
@section('title', 'Medicine Purchase Invoice')
@section('breadcrumb', 'Medicine Purchase Invoice')
@section('body')

<purchase-medicine-invoice id="{{$id}}"></purchase-medicine-invoice>

@endsection