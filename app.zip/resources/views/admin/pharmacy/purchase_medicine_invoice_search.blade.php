@extends('layouts.admin')
@section('title', 'Medicine Purchase Invoice')
@section('breadcrumb', 'Medicine Purchase Invoice')
@section('body')



<purchase-medicine-invoice-search></purchase-medicine-invoice-search>




@endsection