@extends('layouts.admin')
@section('title', 'Medicine Purchase Return Invoice')
@section('breadcrumb', 'Medicine Purchase Return Invoice')
@section('body')

<purchase-return-medicine-invoice id="{{$id}}"></purchase--return-medicine-invoice>

@endsection