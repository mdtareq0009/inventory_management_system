@extends('layouts.admin')
@section('title', 'Medicine Sale Return Invoice')
@section('breadcrumb', 'Medicine Sale Return Invoice')
@section('body')

<sale-return-medicine-invoice id="{{$id}}"></sale--return-medicine-invoice>

@endsection