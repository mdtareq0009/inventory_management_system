@extends('layouts.admin')
@section('title', 'Supplier Due List')
@section('breadcrumb', 'Supplier Due List')
@section('body')

<supplier-due-medicine-report role="{{ auth()->user()->role }}"></supplier-due-medicine-report>

@endsection
