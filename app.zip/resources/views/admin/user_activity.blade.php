@extends('layouts.admin')
@section('title', 'User Activity')
@section('breadcrumb', 'User Activity')
@section('body')

<user-activity></user-activity>

@endsection