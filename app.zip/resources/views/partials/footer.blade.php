<div class="footer">
    <div class="footer-inner">
        <div class="footer-content">
            <div class="row">
                <div class="col-md-9" style="padding-right: 0;">
                    <marquee scrollamount="2" onmouseover="this.stop();" onmouseout="this.start();" direction="left" height="30" style="padding-top: 3px;color: red;margin-bottom: -10px;font-size: 15px;" id="linkup_api"></marquee>
                </div>
                <div class="col-md-3" style="padding: 4px 0;background-color: #3e2e6b;color:white; margin-bottom: -1px;">
                    <span style="font-size: 12px;">
                        Developed by <span class="blue bolder"><a href="http://linktechbd.com/" target="_blank" style="color: white;text-decoration: underline;font-weight: normal;">Link-Up Technology</a></span>
                    </span>
                </div>
            </div>
            
        </div>
    </div>
</div>