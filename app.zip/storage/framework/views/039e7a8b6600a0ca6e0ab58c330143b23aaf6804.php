
<?php $__env->startSection('title', 'Medicine Purchase Record'); ?>
<?php $__env->startSection('breadcrumb', 'Medicine Purchase Record'); ?>
<?php $__env->startSection('body'); ?>

<purchase-medicine-record role="<?php echo e(auth()->user()->role); ?>"></purchase-medicine-record>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\work-sazzat\htdocs\hospital-management-mother\resources\views/admin/pharmacy/purchase_medicine_record.blade.php ENDPATH**/ ?>