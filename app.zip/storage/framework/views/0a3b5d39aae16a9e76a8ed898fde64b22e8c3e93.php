
<?php $__env->startSection('title', 'Medicine Sale Invoice'); ?>
<?php $__env->startSection('breadcrumb', 'Medicine Sale Invoice'); ?>
<?php $__env->startSection('body'); ?>



<sale-medicine-invoice-search></sale-medicine-invoice-search>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\work-sazzat\htdocs\hospital-management-mother\resources\views/admin/pharmacy/sale_medicine_invoice_search.blade.php ENDPATH**/ ?>