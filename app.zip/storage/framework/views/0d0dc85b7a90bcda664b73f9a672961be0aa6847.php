
<?php $__env->startSection('title', 'Test Entry'); ?>
<?php $__env->startSection('breadcrumb', 'Test Entry'); ?>
<?php $__env->startSection('body'); ?>

<test-entry role="<?php echo e(auth()->user()->role); ?>"></test-entry>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\work-sazzat\htdocs\hospital-management-mother\resources\views/admin/pathology/test_entry.blade.php ENDPATH**/ ?>