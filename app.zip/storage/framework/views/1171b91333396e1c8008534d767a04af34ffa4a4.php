
<?php $__env->startSection('title', 'Employee Active List'); ?>
<?php $__env->startSection('breadcrumb', 'Employee Active List'); ?>
<?php $__env->startSection('body'); ?>

<employee-active-list role="<?php echo e(auth()->user()->role); ?>"></employee-active-list>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\work-sazzat\htdocs\hospital-management-mother\resources\views/admin/hrpayroll/employee_active_list.blade.php ENDPATH**/ ?>