
<?php $__env->startSection('title', 'Cash Transaction Report'); ?>
<?php $__env->startSection('breadcrumb', 'Cash Transaction Report'); ?>
<?php $__env->startSection('body'); ?>

<cash-transaction-report role="<?php echo e(auth()->user()->role); ?>"></cash-transaction-report>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\work-sazzat\htdocs\hospital-management-mother\resources\views/admin/accounts/cash_transaction_report.blade.php ENDPATH**/ ?>