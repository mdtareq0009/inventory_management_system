
<?php $__env->startSection('title', 'Medicine Damage Entry'); ?>
<?php $__env->startSection('breadcrumb', 'Medicine Damage Entry'); ?>
<?php $__env->startSection('body'); ?>


<damage-medicine-entry role="<?php echo e(auth()->user()->role); ?>" code="<?php echo e($code); ?>" branch="<?php echo e(auth()->user()->branch_id); ?>"></damage-medicine-entry>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\work-sazzat\htdocs\hospital-management-mother\resources\views/admin/pharmacy/damage_medicine_entry.blade.php ENDPATH**/ ?>