
<?php $__env->startSection('title', 'Bank Ledger'); ?>
<?php $__env->startSection('breadcrumb', 'Bank Ledger'); ?>
<?php $__env->startSection('body'); ?>

<bank-ledger-report role="<?php echo e(auth()->user()->role); ?>"></bank-ledger-report>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\work-sazzat\htdocs\hospital-management-mother\resources\views/admin/accounts/bank_ledger_report.blade.php ENDPATH**/ ?>